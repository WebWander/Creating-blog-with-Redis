import bcrypt from "bcrypt";
import bodyParser from "body-parser";
import cors from 'cors';
import express, { response } from "express";
import { createClient } from "redis";
import session from "express-session";
import RedisStore from "connect-redis";
import path from "path";
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import axios from 'axios';
import querystring from 'querystring';




const __dirname = path.dirname(fileURLToPath(import.meta.url));

dotenv.config();

const PORT = process.env.PORT || 8001;

const app = express();
app.set('view engine', 'ejs');
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.static('public'));
app.use(bodyParser.urlencoded({ extended: true }));



app.use(cors({
  origin: 'http://localhost:8001', 
  credentials: true, 
}))




const redisURL = "redis://127.0.0.1:6379"


// Initialize client
let redisClient = createClient({ url: redisURL });
redisClient.on('connect', () => console.log('Connected to Redis'));
redisClient.on('error', (err) => console.error('Redis Client Error', err));
await redisClient.connect();


// Initialize store
const redisStore = new RedisStore({
  client: redisClient,
  prefix: "session",
});

// Initialize session storage
app.use(
  session({
    secret: "MySecret",
    cookie: { 
      maxAge: 1000 * 60 *60 * 24, 
      secure: false,
      httpOnly: true,
      sameSite: "lax" 
    },
    resave: false,
    saveUninitialized: false,
    store : redisStore,
  })
);



const users = [];


// Get the GitHub login page
app.get('/auth/github', (req, res) => {
  const queryParams = querystring.stringify({
    client_id:'5103c357b99057618807' ,
    redirect_uri: 'http://localhost:8001/auth/callback',
    scope: 'user',
  });

  res.redirect(`https://github.com/login/oauth/authorize?${queryParams}`);
});

app.get('/auth/callback', async (req, res) => {
  const code = req.query.code;

  const tokenParams = {
    client_id: '5103c357b99057618807',
    client_secret: '72afe7ebb03f165e55a70eeaf5a5452bb733880b',
    code,
    redirect_uri: 'http://localhost:8001/auth/callback',
  };

  try {
    const tokenResponse = await axios.post('https://github.com/login/oauth/access_token', tokenParams, {
      headers: {
        Accept: 'application/json',
      },
    });

    const accessToken = tokenResponse.data.access_token;

    const userResponse = await axios.get('https://api.github.com/user', {
      headers: {
        Authorization: `Bearer ${accessToken}`,
      },
    });

    const userData = userResponse.data;
    const existingUser = users.find((user) => user.id === userData.id);

    if (!existingUser) {
      // Add new user to the array
      users.push({
        id: userData.id,
        username: userData.login,
        accessToken: accessToken // Store access token to authenticate future requests
      });
      console.log('New user added from GitHub:', userData);
    }

    // Set user session information
    req.session.isLoggedIn = true;
    req.session.user = userData.login; 
    req.session.githubId = userData.id; 

    // Save the session before sending the response
    req.session.save(err => {
      if (err) {
        console.error('Session save error:', err);
        return res.status(500).send('Error during session save');
      }
      res.redirect('/blogposts'); 
    });

  } catch (error) {
    console.error('Error during GitHub OAuth:', error.message);
    res.status(500).send('Error during GitHub OAuth');
  }
});



const formatDate = (dateString) => {
  const options = { year: 'numeric', month: 'long', day: 'numeric', hour: '2-digit', minute: '2-digit' };
  return new Date(dateString).toLocaleDateString(undefined, options);
};


// Get the home page
app.get('/', async (req, res) => {
  const posts = await fetchBlogPosts();
  res.render('index', { user: req.session.username || null, posts: posts });
});


// Check if the user is logged in
app.get('/check-session', (req, res) => {
  if (req.session.isLoggedIn) {
    res.json({ isLoggedIn: true, user: req.session.username });
  } else {
    res.json({ isLoggedIn: false });
  }
});



//User Registration
app.post('/register', async (req, res) => {
  const { username, password, } = req.body;

  
  if (!username || !password) {
      return res.status(400).send('Username, password, are required.');
  }

  try {
      const existingUser = await redisClient.get(`user:${username}`);
      if (existingUser) {
          return res.status(409).send('Username is already taken');
      }
      const salt = await bcrypt.genSalt(10);
      const hashedPassword = await bcrypt.hash(password, salt);
      await redisClient.set(`user:${username}`, hashedPassword);

      

      res.status(201).send('User registered successfully');

  } catch (err) {
      res.status(500).send('Error registering user');
  }
});





// Get the registration page
app.get('/register', (req, res) => {
  res.render('pages/register', { user: req.session.username || null });
});


// Get the login page
app.get('/login', (req, res) => {
  res.render('pages/login', { user: req.session.username || null });
});


// User Login route
app.post('/login', async (req, res) => {
  const { username, password } = req.body; 
  if (!username || !password) {
    return res.status(400).send('Username and password are required.');
  }
  
  try {
    // Admin login check
    if (username === "May Marie" && password === "12345") {
      // This is the admin user
      req.session.isLoggedIn = true;
      req.session.user = username;
      req.session.isAdmin = true;
      req.session.isUser = false; 

      // Save session and handle admin-specific logic
      req.session.save(err => {
        if (err) {
          return res.status(500).send('Error saving session');
        }
        fetchBlogPosts().then(posts => {
          res.render('pages/blogposts', {
            isAdmin: req.session.isAdmin,
            userRole: 'Admin',
            loggedInUser: req.session.user,
            posts: posts
          });
        });
      });

      req.session.cookie.maxAge = 60 * 60 * 1000; 
    } else {
      const hashedPassword = await redisClient.get(`user:${username}`);
      if (!hashedPassword) {
        return res.status(401).send('User does not exist or wrong username.');
      }
      
      const isMatch = await bcrypt.compare(password, hashedPassword);
      if (isMatch) {
        req.session.isLoggedIn = true;
        req.session.user = username;
        req.session.isAdmin = false;
        req.session.isUser = true;

        
        req.session.save(err => {
          if (err) {
            return res.status(500).send('Error saving session');
          }
          fetchBlogPosts().then(posts => {
            res.render('pages/blogposts', {
              isAdmin: req.session.isAdmin,
              userRole: 'User',
              loggedInUser: req.session.user,
              posts: posts
            });
          });
        });

        req.session.cookie.maxAge = 60 * 60 * 1000; // 1 hour
      } else {
        return res.status(401).send('Invalid password.');
      }
    }
  } catch (err) {
    console.error('Error during login process:', err);
    res.status(500).send('Server error while logging in.');
  }
});


async function fetchBlogPosts() {
  const postIds = await redisClient.SMEMBERS('blogposts');
  const postsPromises = postIds.map(id => redisClient.HGETALL(`blogposts:${id}`));
  const postsData = await Promise.all(postsPromises);
  return postsData.map((postData, index) => ({ id: postIds[index], ...postData })).filter(post => post !== null);
}



// Create a new blog post
app.get('/create-post', (req, res) => {
res.render('pages/create-post', { user: req.session.username });  
});

// Create a new blog post
app.post('/create-post', async (req, res) => {
  console.log(req.body);
  console.log(req.session); 

  if (!req.session.isLoggedIn) {
    console.log('Session: ', req.session);
    return res.status(401).json({ error: 'User not logged in' });
  }

  const { title, text, dateTime } = req.body;
  const author = req.session.user; 

  if (!title || !text || !dateTime) {
    return res.status(400).send('All fields are required');
  }

  try {
    const postId = await redisClient.incr('next_post_id');

    const formattedDateTime = dateTime.replace('T', ' ');
    
    await redisClient.HSET(`blogposts:${postId}`, {
      title, text, author, date: formattedDateTime
    });


    

    await redisClient.SADD('blogposts', postId.toString());

    console.log(`Post created successfully: ${title}`);

    res.redirect('/blogposts');
  } catch (err) {
    console.error('Error creating post:', err);
    res.status(500).send('Error creating post');
  }
});

// Get the blogposts page
app.get('/blogposts', async (req, res) => {
  console.log('Received request for /blogposts');

  if (!req.session.isLoggedIn) {
    return res.status(401).json({ error: 'User not logged in' });
  }

  try {
    const postIds = await redisClient.SMEMBERS('blogposts');
    if (postIds.length === 0) {
      return res.render('pages/blogposts', {
        posts: [],
        userRole: req.session.isAdmin ? 'Admin' : 'User',
        loggedInUser: req.session.user
      });
    }

    const postsPromises = postIds.map(id => redisClient.HGETALL(`blogpost:${id}`)); 
    const postsData = await Promise.all(postsPromises);

    const posts = postsData.map((postData, index) => {
      if (postData) {
        return { id: postIds[index], ...postData };
      }
      return null;
    }).filter(post => post !== null);

    res.render('pages/blogposts', {
      posts: posts,
      userRole: req.session.isAdmin ? 'Admin' : 'User',
      loggedInUser: req.session.user
    });
  } catch (err) {
    console.error('Error fetching posts:', err);
    res.status(500).send('Error fetching posts');
  }
});



app.post('/delete-post', async (req, res) => {
const { postId } = req.body;
const loggedInUser = req.session.user;

try {
  const postAuthor = await redisClient.HGET(`blogposts:${postId}`, 'author');
  if (postAuthor === loggedInUser) {
    await redisClient.del(`blogposts:${postId}`);
    await redisClient.sRem('blogposts', postId);

    res.redirect('/blogposts');
  } else {
    res.status(403).send('You can only delete your own posts');
  }
} catch (err) {
  console.error('Error deleting post:', err);
  res.status(500).send('Error deleting post');
}
});

// Delete post route
app.get('/delete-post', (req, res) => {
res.redirect('/blogposts');
});

// Delete post route
app.get('/delete-all-posts', async (req, res) => {
res.redirect('/blogposts');

});
// Delete all posts route
app.post('/delete-all-posts', async (req, res) => {
try {
  // Check if the user is an admin
  if (!req.session.isAdmin) {
    return res.status(403).send('Permission denied. Only Admins can delete all posts.');
  }

  // Delete all posts from Redis
  const postKeys = await redisClient.keys('blogposts:*');
  await Promise.all(postKeys.map(key => redisClient.del(key)));

  res.redirect('/blogposts');
} catch (err) {
  console.error('Error deleting all posts:', err);
  res.status(500).send('Error deleting all posts');
}
});

// Logout route
app.get('/logout', (req, res) => {
  req.session.destroy((err) => {
      if (err) {
          console.error('Error logging out:', err);
          res.status(500).send('Error logging out');
      } else {
          res.status(200).send('You are logged out');
      }
  });
});


app.listen(PORT,"127.0.0.1", () => {
  console.log(`App listening on port ${PORT}`);
});